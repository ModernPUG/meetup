<?php
/**
 * @package First Plugin
 * @version 0.1
 */
/*
Plugin Name: First Plugin
Plugin URI: 
Description: First Plugin
Author: Jido Park
Version: 0.1
Author URI: 
*/

function first_plugin_filter($title){
    return '제목 : '.$title;
}
add_filter( 'the_title', 'first_plugin_filter', 10, 1);




function custom_login() {
	?>
	<style type="text/css">
	h1 a {
		background:url('http://nextmap.co.kr/mordernphp.png') no-repeat !important;
		width:340px !important;
		height:150px !important;
	}
</style>

	<?php
}
add_action('login_head', 'custom_login');

function my_login_logo_url() {
    return get_bloginfo( 'url' );
}
add_filter( 'login_headerurl', 'my_login_logo_url' );

function my_login_logo_url_title() {
    return 'Your Site Name and Info';
}
add_filter( 'login_headertitle', 'my_login_logo_url_title' );


function annointed_admin_bar_remove() {
        global $wp_admin_bar;

        $wp_admin_bar->remove_menu('wp-logo');
}

add_action('wp_before_admin_bar_render', 'annointed_admin_bar_remove', 0);



add_action( 'admin_menu', 'register_my_custom_menu_page' );
function register_my_custom_menu_page(){

add_menu_page( 'modernphp', 'Modernphp', 'manage_options', 'modernphp', 'modernphp_page', '','2' );
}

function modernphp_page () {
	?>
<h1>MordernPHP!!</h1>
<p>안녕하세요. 워드프레스를 이용해 다양한 플러그인을 만들어보세요 ^^</p>

	<?php
}
	?>